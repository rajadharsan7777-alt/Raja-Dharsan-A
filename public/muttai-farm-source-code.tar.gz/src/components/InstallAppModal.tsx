import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  X, 
  Share2, 
  ExternalLink, 
  Sparkles,
  Layers,
  ShieldCheck,
  Zap,
  HelpCircle,
  Check
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  appUrl: string;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  appUrl,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'direct' | 'apk' | 'help'>('direct');
  const [installSuccess, setInstallSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setInstallSuccess(true);
      }
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl || window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const pwaBuilderUrl = `https://www.pwabuilder.com?site=${encodeURIComponent(appUrl || window.location.href)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-amber-50 border-2 border-amber-300 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-white flex items-center justify-between shadow-md shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 p-1 flex items-center justify-center shadow-inner shrink-0">
              <img src="/pwa-192x192.png" alt="App Icon" className="w-full h-full object-contain rounded-xl" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base sm:text-lg font-bold tracking-tight">போனில் ஆப் (App / APK)</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-amber-950">
                  5 சாதனங்கள்
                </span>
              </div>
              <p className="text-[11px] text-amber-100">
                போனில் நேரடி ஆப்பாக வைத்துப் பயன்படுத்தும் வழிகாட்டல்
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition active:scale-95 text-white shrink-0"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="flex border-b border-amber-200 bg-amber-100/70 p-1.5 gap-1 text-xs font-bold shrink-0">
          <button
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
              activeTab === 'direct'
                ? 'bg-white text-amber-950 shadow-sm border border-amber-200 font-extrabold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-600" />
            <span>நேரடி ஆப் (PWA)</span>
            <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1 py-0.5 rounded">பரிந்துரை</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2 px-2 rounded-xl flex items-center justify-center gap-1.5 transition ${
              activeTab === 'apk'
                ? 'bg-white text-amber-950 shadow-sm border border-amber-200 font-extrabold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Download className="w-3.5 h-3.5 text-amber-600" />
            <span>APK விளக்கம்</span>
          </button>
          <button
            onClick={() => setActiveTab('help')}
            className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1 transition ${
              activeTab === 'help'
                ? 'bg-white text-amber-950 shadow-sm border border-amber-200 font-extrabold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
            <span>உதவி</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-stone-800 flex-1">
          {activeTab === 'direct' && (
            <>
              {/* Direct Install Card */}
              <div className="bg-white rounded-2xl p-4 border border-amber-200 shadow-sm space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-500 text-white shadow-md shrink-0">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-stone-900">
                      போனின் Home Screen-ல் முழு ஆப்பாக நிறுவுதல்
                    </h4>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                      இது உங்கள் போனில் சாதாரண APK ஆப் போல முகப்புத் திரையில் நிறுவப்பட்டு தனி ஆப்பாக இயங்கும். URL பார் இருக்காது!
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-1.5 font-semibold text-stone-800">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>0 MB இடம் (No Lag)</span>
                  </div>
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-1.5 font-semibold text-stone-800">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>உடனடி மணி ஒலி</span>
                  </div>
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-1.5 font-semibold text-stone-800">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>5 போன் ஆட்டோ-சிங்க்</span>
                  </div>
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-1.5 font-semibold text-stone-800">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>தானியங்கி அப்டேட்</span>
                  </div>
                </div>

                {/* Primary Action Button */}
                <div className="pt-1">
                  {isInstalled || installSuccess ? (
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-center flex items-center justify-center gap-2 text-emerald-800 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>ஆப் உங்கள் சாதனத்தில் வெற்றிகரமாக இன்ஸ்டால் செய்யப்பட்டுள்ளது!</span>
                    </div>
                  ) : isInstallable ? (
                    <button
                      onClick={handleInstallClick}
                      className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-extrabold text-sm shadow-md transition flex items-center justify-center gap-2 active:scale-98"
                    >
                      <Download className="w-4 h-4" />
                      <span>இப்போதே போனில் இன்ஸ்டால் செய் (Install App)</span>
                    </button>
                  ) : (
                    <div className="p-3 bg-amber-100/80 border border-amber-300 rounded-xl text-xs space-y-2">
                      <div className="font-bold text-amber-950 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-amber-800" />
                        <span>Chrome பிரவுசரில் 2 வினாடியில் இன்ஸ்டால் செய்யும் முறை:</span>
                      </div>
                      <ol className="list-decimal list-inside space-y-1.5 text-stone-800 font-medium pl-1">
                        <li>Chrome பிரவுசரின் வலது மேல் மூலையில் உள்ள <strong>3 புள்ளிகளை (⋮)</strong> தொடவும்.</li>
                        <li>அதில் <strong>"Install app"</strong> அல்லது <strong>"Add to Home screen" (முகப்புத்திரையில் சேர்)</strong> என்பதைத் தொடவும்.</li>
                        <li>உடனே போனில் வாட்ஸ்அப் போல <strong>"முட்டை பண்ணை"</strong> ஐகான் வந்துவிடும்!</li>
                      </ol>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {activeTab === 'apk' && (
            <>
              {/* Explanation of APK */}
              <div className="bg-white rounded-2xl p-4 border border-amber-200 shadow-sm space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-md shrink-0">
                    <Download className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-stone-900">
                      APK ஏன் வரவில்லை? உண்மை விளக்கம்:
                    </h4>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                      வழக்கமான <strong>.apk</strong> கோப்புக்கு போனில் 50MB ஸ்டோரேஜ் தேவைப்படும் மற்றும் அப்டேட் செய்யும்போது மீண்டும் மீண்டும் டவுன்லோட் செய்ய வேண்டும்.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs space-y-2">
                  <div className="font-bold text-amber-950">கூகுளின் புதிய WebAPK முறை:</div>
                  <p className="text-stone-700 leading-relaxed">
                    நீங்கள் Chrome-ல் <strong>"Install App"</strong> கொடுக்கும்போது, ஆண்ட்ராய்டு போனின் இயங்குதளமே தானாகவே ஒரு <strong>அதிகாரப்பூர்வ WebAPK</strong>-வை உருவாக்கி போனில் இன்ஸ்டால் செய்துவிடும். இது சாதாரண APK-வை விட 10 மடங்கு வேகமானது மற்றும் எப்போதும் புதிய கணக்குகளுடன் தானாகவே அப்டேட் ஆகும்.
                  </p>
                </div>

                <div className="p-3 bg-stone-100 rounded-xl border border-stone-200 text-xs space-y-2">
                  <div className="font-bold text-stone-800 flex items-center justify-between">
                    <span>சுயாதீன APK மாற்றிக் கொள்ள (Developer Tool):</span>
                  </div>
                  <p className="text-stone-600 text-[11px]">
                    நீங்கள் தனிப்பட்ட முறையில் Google Play Store அல்லது APK தொகுக்க விரும்பினால் PWABuilder தளத்தைப் பயன்படுத்தலாம்:
                  </p>
                  <a
                    href={pwaBuilderUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-blue-700 font-bold hover:underline"
                  >
                    <span>PWABuilder-ல் APK உருவாக்கு</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </>
          )}

          {activeTab === 'help' && (
            <div className="bg-white rounded-2xl p-4 border border-amber-200 shadow-sm space-y-4 text-xs">
              <h4 className="font-bold text-sm text-stone-900 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-amber-600" />
                <span>அடிக்கடி கேட்கப்படும் கேள்விகள் (FAQ)</span>
              </h4>

              <div className="space-y-3">
                <div className="p-2.5 rounded-xl bg-amber-50/60 border border-amber-100">
                  <div className="font-bold text-stone-900">கேள்வி: ஆப் டவுன்லோட் பட்டன் தெரியவில்லையா?</div>
                  <p className="text-stone-600 mt-1 leading-relaxed">
                    Chrome-ன் மேல் வலது 3 புள்ளிகளைத் தொட்டு <strong>"Add to Home Screen"</strong> அல்லது <strong>"Install App"</strong> கொடுக்கவும்.
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-amber-50/60 border border-amber-100">
                  <div className="font-bold text-stone-900">கேள்வி: 5 போன்களுக்கும் மணி ஒலி கேட்குமா?</div>
                  <p className="text-stone-600 mt-1 leading-relaxed">
                    ஆம்! ஒவ்வொரு போனிலும் ஆப்பைத் திறந்து தனித்தனி சாதனத்தை (சாதனம் 1 - 5) தேர்வு செய்துகொண்டால், யார் முட்டை உள்ளிட்டாலும் உடனே மணி ஒலிக்கும்.
                  </p>
                </div>
              </div>

              {/* Copy app link */}
              <div className="pt-2 border-t border-stone-200">
                <label className="block font-bold text-stone-700 mb-1 text-[11px]">ஆப் இணைப்பு (Copy Link):</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={appUrl || window.location.href}
                    className="flex-1 bg-stone-50 border border-stone-200 px-3 py-1.5 rounded-xl text-stone-600 text-xs select-all"
                  />
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 bg-amber-600 text-white rounded-xl font-bold flex items-center gap-1 shrink-0 text-xs"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-white" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'நகலானது' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-amber-100 border-t border-amber-200 flex items-center justify-between">
          <span className="text-[11px] text-amber-900 font-semibold">
            தமிழ்நாடு முட்டை பண்ணை மேலாண்மை
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white font-bold text-xs rounded-xl transition"
          >
            மூடு (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
