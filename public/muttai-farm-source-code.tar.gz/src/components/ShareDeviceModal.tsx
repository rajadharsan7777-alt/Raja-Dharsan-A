import React, { useState } from 'react';
import { Copy, Check, Smartphone, QrCode, ExternalLink, ShieldCheck, AlertTriangle, Send } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareDeviceModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  
  // Use public/standalone app url if available, otherwise origin
  const currentUrl = window.location.origin;

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const handleWhatsAppShare = () => {
    const text = `🥚 முட்டை பண்ணை கணக்கு ஆப் (5 சாதனங்கள் இணைப்பு):\n\nகீழே உள்ள இணைப்பைத் திறந்து பயன்படுத்தவும்:\n${currentUrl}\n\n(குறிப்பு: பிரவுசரில் திறந்து மேலே உள்ள 3 புள்ளிகளைத் தொட்டு "Install app" அல்லது "Add to Home Screen" கொடுத்தால் ஆப்பாக மாறிவிடும்!)`;
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(waUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="bg-stone-50 border-2 border-amber-200 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-200">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-amber-500 text-white rounded-xl shadow-sm">
              <Smartphone className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-base text-stone-900">
                மற்ற போன்களில் திறப்பது எப்படி?
              </h3>
              <p className="text-xs text-stone-500">5 சாதனங்களையும் எளிதாக இணைக்கவும்</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-stone-400 hover:text-stone-700 p-1.5 rounded-xl transition hover:bg-stone-200/50"
          >
            ✕
          </button>
        </div>

        <div className="my-4 space-y-3.5">
          {/* 403 Error Warning & Fix */}
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-xs space-y-1.5">
            <div className="font-bold text-rose-900 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>403 பிழை (403 That's an error) ஏன் வருகிறது?</span>
            </div>
            <p className="text-[11px] text-rose-800 leading-relaxed">
              பிரவுசரின் மேலே தெரியும் <code className="bg-rose-100 px-1 py-0.5 rounded font-mono text-[10px]">aistudio.google.com</code> முகவரியை அனுப்பினால், கூகுள் பாதுகாப்பு காரணத்தால் மற்ற போன்களில் <strong>403 Forbidden</strong> எனத் தடுக்கும்.
            </p>
            <div className="pt-1 text-[11px] text-stone-700 font-medium">
              💡 <strong>தீர்வு:</strong> கீழே உள்ள <strong>"WhatsApp-ல் அனுப்பு"</strong> அல்லது <strong>"Copy Link"</strong> பட்டனைப் பயன்படுத்தி மட்டுமே லிங்கைப் பகிரவும்!
            </div>
          </div>

          {/* QR Code */}
          <div className="p-3 bg-white border-2 border-dashed border-amber-300 rounded-2xl flex flex-col items-center justify-center text-center">
            <div className="w-32 h-32 bg-amber-50 rounded-xl flex items-center justify-center border border-amber-200 shadow-inner my-1">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=${encodeURIComponent(
                  currentUrl
                )}`}
                alt="QR Code"
                className="w-28 h-28 rounded-lg"
                loading="lazy"
              />
            </div>
            <p className="text-xs text-stone-600 font-medium mt-1">
              மற்ற போன் கேமராவால் இந்த QR-ஐ ஸ்கேன் செய்யவும்
            </p>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              WhatsApp-ல் அனுப்பு
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'லிங்க் காப்பி ஆனது!' : 'சரியான லிங்க் Copy'}
            </button>
          </div>

          {/* Setup guide */}
          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-stone-700 space-y-1.5">
            <div className="font-bold text-amber-900 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              5 போன்களையும் இணைப்பது எப்படி?
            </div>
            <ol className="list-decimal list-inside space-y-1 text-[11px] text-stone-600">
              <li>மற்ற 4 போன்களிலும் Chrome பிரவுசரில் உங்கள் Gmail கணக்கு அல்லது இந்த நேரடி லிங்கைத் திறக்கவும்.</li>
              <li>Chrome-ல் வலதுபுறம் உள்ள <strong>3 புள்ளிகளை (⋮) தொட்டு "Install app" (அல்லது Add to Home screen)</strong> கொடுத்தால் ஆப்பாக மாறிவிடும்.</li>
              <li>மேலே உள்ள "சாதனம்" பட்டனை அழுத்தி <strong>சாதனம் 1 முதல் 5 வரை</strong> தனித்தனியாக தேர்வு செய்யவும்.</li>
              <li>எந்தப் போனில் பதிவு செய்தாலும் 5 போன்களுக்கும் உடனே மணி ஒலிக்கும்!</li>
            </ol>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold rounded-xl transition shadow-sm"
        >
          சரி (Done)
        </button>
      </div>
    </div>
  );
};
